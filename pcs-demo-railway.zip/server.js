require("dotenv").config();

const express = require("express");
const session = require("express-session");
const { Pool } = require("pg");
const crypto = require("crypto");
const path = require("path");

const app = express();
const port = Number(process.env.PORT || 3000);

if (!process.env.DATABASE_URL) {
  console.warn("DATABASE_URL is not configured.");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes("localhost")
    ? { rejectUnauthorized: false }
    : false
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use(session({
  secret: process.env.SESSION_SECRET || "demo-only-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" }
}));

app.use((req, res, next) => {
  res.locals.isAdmin = !!req.session.admin;
  res.locals.demoMode = true;
  next();
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS demo_codes (
      id SERIAL PRIMARY KEY,
      code VARCHAR(40) UNIQUE NOT NULL,
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      status VARCHAR(20) NOT NULL DEFAULT 'available'
        CHECK (status IN ('available','used')),
      used_by VARCHAR(120),
      used_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS demo_payments (
      id SERIAL PRIMARY KEY,
      reference VARCHAR(40) UNIQUE NOT NULL,
      donor_name VARCHAR(120),
      email VARCHAR(180),
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      code_id INTEGER REFERENCES demo_codes(id),
      status VARCHAR(20) NOT NULL DEFAULT 'paid'
        CHECK (status IN ('paid','cancelled')),
      message TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);

  const count = await pool.query("SELECT COUNT(*)::int AS n FROM demo_codes");
  if (count.rows[0].n === 0) {
    const seed = [
      ["PCS-DEMO-1001", 1000],
      ["PCS-DEMO-2002", 2000],
      ["PCS-DEMO-5005", 5000],
      ["PCS-DEMO-10010", 10000],
      ["PCS-DEMO-20020", 20000]
    ];
    for (const [code, amount] of seed) {
      await pool.query(
        "INSERT INTO demo_codes (code, amount_cents) VALUES ($1,$2) ON CONFLICT DO NOTHING",
        [code, amount]
      );
    }
  }
}

function makeReference() {
  return "DEMO-" + crypto.randomBytes(5).toString("hex").toUpperCase();
}

function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.redirect("/admin/login");
  next();
}

app.get("/", async (req, res) => {
  const stats = await pool.query(`
    SELECT
      (SELECT COUNT(*) FROM demo_codes WHERE status='available')::int AS available,
      (SELECT COUNT(*) FROM demo_payments WHERE status='paid')::int AS payments,
      COALESCE((SELECT SUM(amount_cents) FROM demo_payments WHERE status='paid'),0)::int AS total
  `);
  res.render("index", { stats: stats.rows[0] });
});

app.get("/pay", async (req, res) => {
  const amounts = [5, 10, 20, 50, 100, 200];
  res.render("pay", { amounts, error: null, values: {} });
});

app.post("/pay", async (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 120);
  const email = String(req.body.email || "").trim().slice(0, 180);
  const message = String(req.body.message || "").trim().slice(0, 500);
  const rawAmount = Number(req.body.amount);

  if (!Number.isFinite(rawAmount) || ![5,10,20,50,100,200].includes(rawAmount)) {
    return res.status(400).render("pay", {
      amounts: [5,10,20,50,100,200],
      error: "Montant de démonstration invalide.",
      values: req.body
    });
  }

  const amountCents = Math.round(rawAmount * 100);

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Only fictional demo inventory is used.
    const codeResult = await client.query(
      `SELECT * FROM demo_codes
       WHERE amount_cents=$1 AND status='available'
       ORDER BY id
       FOR UPDATE SKIP LOCKED
       LIMIT 1`,
      [amountCents]
    );

    if (!codeResult.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).render("pay", {
        amounts: [5,10,20,50,100,200],
        error: "Aucun code de démonstration disponible pour ce montant.",
        values: req.body
      });
    }

    const code = codeResult.rows[0];
    const reference = makeReference();

    await client.query(
      `UPDATE demo_codes
       SET status='used', used_by=$1, used_at=NOW()
       WHERE id=$2`,
      [email || name || "demo-user", code.id]
    );

    await client.query(
      `INSERT INTO demo_payments
       (reference, donor_name, email, amount_cents, code_id, status, message)
       VALUES ($1,$2,$3,$4,$5,'paid',$6)`,
      [reference, name || null, email || null, amountCents, code.id, message || null]
    );

    await client.query("COMMIT");
    res.redirect("/success/" + encodeURIComponent(reference));
  } catch (err) {
    await client.query("ROLLBACK");
    console.error(err);
    res.status(500).render("pay", {
      amounts: [5,10,20,50,100,200],
      error: "Erreur serveur de démonstration.",
      values: req.body
    });
  } finally {
    client.release();
  }
});

app.get("/success/:reference", async (req, res) => {
  const result = await pool.query(`
    SELECT p.*, c.code
    FROM demo_payments p
    JOIN demo_codes c ON c.id=p.code_id
    WHERE p.reference=$1
  `, [req.params.reference]);

  if (!result.rowCount) return res.status(404).render("404");
  res.render("success", { payment: result.rows[0] });
});

app.get("/admin/login", (req, res) => {
  res.render("admin-login", { error: null });
});

app.post("/admin/login", (req, res) => {
  const expected = process.env.ADMIN_PASSWORD || "demo-admin";
  if (String(req.body.password || "") === expected) {
    req.session.admin = true;
    return res.redirect("/admin");
  }
  res.status(401).render("admin-login", { error: "Mot de passe incorrect." });
});

app.post("/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.redirect("/"));
});

app.get("/admin", requireAdmin, async (req, res) => {
  const [codes, payments, totals] = await Promise.all([
    pool.query("SELECT * FROM demo_codes ORDER BY id DESC"),
    pool.query(`
      SELECT p.*, c.code
      FROM demo_payments p
      JOIN demo_codes c ON c.id=p.code_id
      ORDER BY p.created_at DESC
      LIMIT 100
    `),
    pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE status='available')::int AS available,
        COUNT(*) FILTER (WHERE status='used')::int AS used,
        COALESCE(SUM(amount_cents) FILTER (WHERE status='paid'),0)::int AS total
      FROM demo_codes c
      FULL OUTER JOIN demo_payments p ON FALSE
    `)
  ]);
  res.render("admin", {
    codes: codes.rows,
    payments: payments.rows,
    totals: totals.rows[0]
  });
});

app.post("/admin/codes", requireAdmin, async (req, res) => {
  const amount = Number(req.body.amount);
  const qty = Math.min(Math.max(Number(req.body.quantity) || 1, 1), 100);
  if (![5,10,20,50,100,200].includes(amount)) return res.redirect("/admin");

  for (let i = 0; i < qty; i++) {
    const suffix = crypto.randomBytes(3).toString("hex").toUpperCase();
    const code = `PCS-DEMO-${amount}-${suffix}`;
    await pool.query(
      "INSERT INTO demo_codes (code, amount_cents) VALUES ($1,$2)",
      [code, amount * 100]
    );
  }
  res.redirect("/admin");
});

app.post("/admin/codes/:id/reset", requireAdmin, async (req, res) => {
  await pool.query(
    "UPDATE demo_codes SET status='available', used_by=NULL, used_at=NULL WHERE id=$1",
    [req.params.id]
  );
  res.redirect("/admin");
});

app.use((req, res) => res.status(404).render("404"));

initDb()
  .then(() => app.listen(port, () => console.log(`Demo site running on port ${port}`)))
  .catch(err => {
    console.error("Database initialization failed:", err);
    process.exit(1);
  });
