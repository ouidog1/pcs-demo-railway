# PCS Demo — prêt pour Railway

Prototype complet d'un parcours de paiement utilisant **uniquement des codes fictifs**.

> Ce projet n'est pas affilié à PCS. Il ne traite aucun vrai paiement et ne doit pas être présenté comme un moyen de paiement PCS réel.

## Fonctionnalités

- Accueil moderne
- Parcours de paiement démo
- Montants de test : 5 / 10 / 20 / 50 / 100 / 200 €
- Codes fictifs `PCS-DEMO-*`
- PostgreSQL
- Réservation atomique des codes pour éviter les doubles utilisations
- Page de confirmation avec référence
- Tableau de bord admin
- Génération de nouveaux codes fictifs
- Réinitialisation d'un code de test
- Compatible Railway

## Lancer en local

1. Installer Node.js 20+ et PostgreSQL.
2. Copier `.env.example` vers `.env`.
3. Renseigner `DATABASE_URL`.
4. Définir `ADMIN_PASSWORD`.
5. Installer les dépendances :

```bash
npm install
npm start
```

Puis ouvrir `http://localhost:3000`.

## Déployer sur Railway

1. Créer un nouveau projet Railway.
2. Ajouter un service PostgreSQL.
3. Ajouter ce dépôt GitHub ou importer le projet.
4. Dans les variables du service web, ajouter :

```text
DATABASE_URL=${{Postgres.DATABASE_URL}}
SESSION_SECRET=une-longue-valeur-aleatoire
ADMIN_PASSWORD=un-mot-de-passe-fort
BASE_URL=https://ton-domaine
```

Railway fournit automatiquement `PORT`.

5. Le service démarre avec `npm start`.
6. Ouvrir le domaine Railway généré.
7. Aller sur `/admin` pour administrer les codes de test.

## Important

Les codes présents dans la base sont volontairement fictifs. Ne remplace pas cette logique par la collecte ou la validation de vrais codes de recharge appartenant à des utilisateurs.

Avant toute mise en production avec de vrais paiements, il faut remplacer ce mécanisme par une solution de paiement officielle et autorisée, avec les obligations légales, fiscales et de sécurité correspondantes.
